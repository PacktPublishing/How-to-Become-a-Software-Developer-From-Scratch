export class InvoiceLine {
  description: string;
  rate: number;
  energyConsumed: number;
  totalAmount: number;
}
