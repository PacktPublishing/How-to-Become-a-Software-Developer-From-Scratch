package com.softwarewithpassion.electricityplansimproved;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectricityPlansImprovedApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectricityPlansImprovedApplication.class, args);
	}

}
