package com.softwarewithpassion.electricityplans;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectricityPlansApplicationTests {

	@Test
	void contextLoads() {
	}

}
