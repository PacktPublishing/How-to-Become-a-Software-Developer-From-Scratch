package com.softwarewithpassion.electricityplans;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectricityPlansApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectricityPlansApplication.class, args);
	}

}
