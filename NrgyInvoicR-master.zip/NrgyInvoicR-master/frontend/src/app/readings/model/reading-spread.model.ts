export class ReadingSpread {
  numberOfMeasuredValues: number;
  numberOfExpectedValues: number;
}
