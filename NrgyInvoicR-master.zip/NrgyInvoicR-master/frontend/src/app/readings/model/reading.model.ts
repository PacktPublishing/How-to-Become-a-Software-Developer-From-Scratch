import { ReadingSpread } from './reading-spread.model';

export class Reading {
  readingSpread: ReadingSpread;
}
