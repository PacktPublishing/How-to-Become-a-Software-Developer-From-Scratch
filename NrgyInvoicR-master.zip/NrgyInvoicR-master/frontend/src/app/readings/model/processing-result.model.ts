export enum ProcessingResult {
  WAITING, SUCCESS, ERROR
}
