export class LineError {
  public lineNumber: number;
  public errorMessage: string;
}
