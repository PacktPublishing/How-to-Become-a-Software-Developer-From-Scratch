export class FlattenedBucket {
  public unitPrice: number;
  public description: string;
}
