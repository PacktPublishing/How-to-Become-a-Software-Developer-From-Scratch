import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './plans-page.component.html'
})
export class PlansPageComponent implements OnInit {

  constructor() { }

  ngOnInit() { }
}
