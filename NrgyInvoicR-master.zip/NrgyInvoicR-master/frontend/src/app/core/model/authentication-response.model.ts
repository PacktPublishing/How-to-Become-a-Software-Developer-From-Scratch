export class AuthenticationResponse {

  constructor(public authenticationToken: string) { }
}
