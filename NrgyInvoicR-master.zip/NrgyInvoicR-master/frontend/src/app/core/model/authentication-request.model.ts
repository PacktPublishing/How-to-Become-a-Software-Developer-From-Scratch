export class AuthenticationRequest {

  constructor(public email: string, public password: string) { }
}
