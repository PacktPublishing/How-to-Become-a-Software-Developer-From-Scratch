package com.softwarewithpassion.nrgyinvoicr.backend.readings.entity;

public enum ReadingUploadStatus {
    OK, ERROR
}
