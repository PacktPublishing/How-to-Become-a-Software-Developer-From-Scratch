package com.softwarewithpassion.nrgyinvoicr.backend.invoices.entity;

public enum Unit {
    NONE, KWH
}
