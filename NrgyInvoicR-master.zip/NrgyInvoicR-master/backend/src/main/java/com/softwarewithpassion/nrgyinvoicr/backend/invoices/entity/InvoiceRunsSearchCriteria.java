package com.softwarewithpassion.nrgyinvoicr.backend.invoices.entity;

import com.softwarewithpassion.nrgyinvoicr.backend.PageDefinition;

public class InvoiceRunsSearchCriteria {
    private PageDefinition pageDefinition;

    public PageDefinition getPageDefinition() {
        return pageDefinition;
    }

    public void setPageDefinition(PageDefinition pageDefinition) {
        this.pageDefinition = pageDefinition;
    }
}
