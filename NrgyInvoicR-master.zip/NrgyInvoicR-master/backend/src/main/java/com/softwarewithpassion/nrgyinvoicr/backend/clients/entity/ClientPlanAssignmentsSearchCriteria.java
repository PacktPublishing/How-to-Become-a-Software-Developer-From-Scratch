package com.softwarewithpassion.nrgyinvoicr.backend.clients.entity;

import com.softwarewithpassion.nrgyinvoicr.backend.PageDefinition;

public class ClientPlanAssignmentsSearchCriteria {
    private PageDefinition pageDefinition;

    public PageDefinition getPageDefinition() {
        return pageDefinition;
    }

    public void setPageDefinition(PageDefinition pageDefinition) {
        this.pageDefinition = pageDefinition;
    }
}
