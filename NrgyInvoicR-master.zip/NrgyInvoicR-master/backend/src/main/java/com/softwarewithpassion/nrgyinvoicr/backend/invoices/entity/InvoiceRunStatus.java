package com.softwarewithpassion.nrgyinvoicr.backend.invoices.entity;

public enum InvoiceRunStatus {
    NEW, STARTED, FINISHED
}
