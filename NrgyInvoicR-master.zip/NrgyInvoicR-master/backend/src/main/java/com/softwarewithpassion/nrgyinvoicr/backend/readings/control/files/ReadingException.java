package com.softwarewithpassion.nrgyinvoicr.backend.readings.control.files;

public class ReadingException extends Exception {

    ReadingException(String message) {
        super(message);
    }
}
