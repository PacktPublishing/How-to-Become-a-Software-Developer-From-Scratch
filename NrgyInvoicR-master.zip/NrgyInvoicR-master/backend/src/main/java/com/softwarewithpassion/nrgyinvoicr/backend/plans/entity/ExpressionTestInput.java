package com.softwarewithpassion.nrgyinvoicr.backend.plans.entity;

public class ExpressionTestInput {

    private String expression;

    public String getExpression() {
        return expression;
    }

    public void setExpression(String expression) {
        this.expression = expression;
    }
}
