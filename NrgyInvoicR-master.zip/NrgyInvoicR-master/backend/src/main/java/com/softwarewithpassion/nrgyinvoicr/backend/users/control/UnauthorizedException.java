package com.softwarewithpassion.nrgyinvoicr.backend.users.control;

public class UnauthorizedException extends Exception {
}
