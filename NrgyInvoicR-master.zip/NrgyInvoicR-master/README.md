# How to Become a Software Developer From Scratch

This project contains source code for the sample enterprise web application for the course [How to Become a Software Developer From Scratch](https://www.udemy.com/course/how-to-become-a-software-developer-from-scratch/?referralCode=FDFA9FC121D27830A15E).

### NrgyInvoicR handles your energy business with speed and ease.

Import meters data from your customers and start issuing invoices right away!
