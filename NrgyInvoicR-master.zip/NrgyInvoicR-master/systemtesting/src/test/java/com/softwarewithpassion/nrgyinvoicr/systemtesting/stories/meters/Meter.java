package com.softwarewithpassion.nrgyinvoicr.systemtesting.stories.meters;

public class Meter {
    public final String serialNumber;

    Meter(String serialNumber) {
        this.serialNumber = serialNumber;
    }
}
